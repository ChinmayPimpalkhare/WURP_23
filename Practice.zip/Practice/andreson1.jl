using JuMP
using Ipopt

# Define the model
model = Model(optimizer_with_attributes(Ipopt.Optimizer, "print_level" => 0))

# Define variables
@variable(model, x[1:3])

# Define variables for t
nt = 2  # assuming nt is the number of elements in t
@variable(model, 0 <= t[1:nt] <= 2)

# Define the objective function
@objective(model, Min, x[3])

# Define constraints
@constraint(model, -x[1]*t[1] - x[2]*t[2] - x[3] - (1/6)*((t[1]-1)^2 + t[2])*(t[1] + (2-t[2])) <= 0)

# Solve the optimization problem
optimize!(model)

# Display the results
println("Optimal value of x[3]: ", value(x[3]))
println("Optimal values of t: ", value.(t))
