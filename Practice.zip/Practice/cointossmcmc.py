import scipy.stats as stats
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

x = 57
n = 100

def likelihood(p): 
    return stats.binom.pmf(x,n,p)

def prior(p):
    return stats.uniform.pdf(p)

def acceptance_ratio(p, p_new): 
    return min(1, ((likelihood(p_new)/likelihood(p))*(prior(p_new)/prior(p))))

results = []
p = np.random.uniform(0,1)

n_samples = 25000
burn_in = 5000
lag = 5

for i in range(n_samples):
    p_new = np.random.random_sample()
    R = acceptance_ratio(p, p_new)
    u = np.random.random_sample()
    if u < R: 
        p = p_new
    if i > burn_in and i%lag == 0: 
        results.append(p)

# Traceplot with mean line
plt.figure(figsize=(10, 5))
plt.subplot(2, 1, 1)
plt.plot(results, label='Traceplot')
plt.axhline(np.mean(results), color='red', linestyle='--', label='Mean')
plt.title('Traceplot of p with Mean Line')
plt.xlabel('Iteration')
plt.ylabel('p')
plt.legend()

# Posterior distribution plot with best-fitted line and normal distribution overlay
plt.subplot(2, 1, 2)
plt.hist(results, bins=30, density=True, alpha=0.7, color='skyblue', edgecolor='black', label='Posterior Distribution')
plt.axvline(np.mean(results), color='red', linestyle='--', label='Mean')
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = stats.uniform.pdf(x)
plt.plot(x, p, 'k', linewidth=2, label='Best-Fitted Line (Uniform Prior)')

# Add normal distribution overlay
mu, std = np.mean(results), np.std(results)
p = stats.norm.pdf(x, mu, std)
plt.plot(x, p, 'r--', linewidth=2, label='Normal Distribution (Fit)')
plt.title('Posterior Distribution of p with Best-Fitted Line and Normal Distribution Overlay')
plt.xlabel('p')
plt.ylabel('Density')
plt.legend()

# Adjust layout to prevent overlap
plt.tight_layout()

# Show the plots
plt.show()