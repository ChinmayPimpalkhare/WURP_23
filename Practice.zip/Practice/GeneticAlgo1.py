from pulp import * 
import numpy as np 
import random
import time

dimx = 3
dimt = 2
dimx_plus_1  = dimx + 1
t_min = 0
t_max = 2

population = 100
selected = 100
generation = np.zeros((population, dimx, dimt))
fitness_generation = np.zeros(population)
best_organism = np.zeros((dimx, dimt))
max_fitness = 0
mutation_rate = 0.1
n_iterations = 1
MINIMUM_N = -1e8
MAXIMUM_N = 1e8

def evaluate_t_constraints(uncertainties):
    global dimx, dimt, dimx_plus_1
    constraint_coeff_array = np.zeros((dimx, dimx_plus_1))
    for i in range(0,dimx): 
        constraint_coeff_array[i][0] = -uncertainties[i][0]
        constraint_coeff_array[i][1] = -uncertainties[i][1]
        constraint_coeff_array[i][2] = -1
        constraint_coeff_array[i][3] = -1/6*((uncertainties[i][0] - 1)**2 \
                                             + uncertainties[i][1])\
            *(uncertainties[i][0] + (2 - uncertainties[i][1]))        
    return constraint_coeff_array

def solve_for_G_of_omega(constraint_coeff_array): 
    global dimx, MINIMUM_N, MAXIMUM_N
    prob = LpProblem("FindG", LpMinimize)
    set_x = range(0, dimx)
    set_t = range(0, dimt)
    G_omega = LpVariable.dicts("x", lowBound=MINIMUM_N, upBound=MAXIMUM_N, indices=set_x, cat = 'Continuous')
    prob += G_omega[2]
    for i in set_x: 
        prob += 0 >= G_omega[0]*constraint_coeff_array[i][0] + \
        G_omega[1]*constraint_coeff_array[i][1] + G_omega[2]*constraint_coeff_array[i][2] +\
        constraint_coeff_array[i][3]
    #print(prob)
    prob.solve(PULP_CBC_CMD(msg = 0))
    G_of_omega = np.array([G_omega[i].varValue for i in set_x])
    return G_of_omega[2]

def initialize_organisms():
    global generation, t_min, t_max, population, dimx, dimt
    for i in range(0, population): 
        for j in range(0, dimx): 
            for k in range(0, dimt): 
                generation[i][j][k] = random.uniform(t_min, t_max)
    print(generation)
    return  

#Here, we define the fitness transformation which is so as to drive the generations
#towards convergence
def min_fitness_transformation_function(input_array): 
    #using exponentiation transformation $H = f**a/(summation(f**a))$
    selection_exponent = 0.000001
    size_array = len(input_array)
    output_array = np.zeros(size_array)
    output_array = np.exp(selection_exponent*input_array)/\
    np.sum(np.exp(selection_exponent*input_array))
    #print("Sum:", np.sum(output_array))
    return output_array

def selection():
    global population, generation, fitness_generation
    # First we want to compute the fitness values of each of the organisms from
    # the generation and then we want to store it inside of the fitness array 
    # The fitness value of the i^th organism in the generation will be stored inside 
    # of the i^th indexed element of the fitness_generation array 
    for i in range(population): 
        fitness_generation[i] = solve_for_G_of_omega(evaluate_t_constraints(generation[i]))
    #First, compute the transformation function over the space
    print("1:", fitness_generation) 
    selection_probabilities = min_fitness_transformation_function(fitness_generation)
    #print("2:", fitness_generation)
    print("SP:", selection_probabilities)
    #Now we shall want to select a number which is selected*population
    indices = np.random.choice(population, population, p = selection_probabilities)
    print(indices)
    temp_generation = generation.copy()
    for i in range(population):
        generation[i] = temp_generation[indices[i]]
    print("2:", generation)
    return 

def crossover(): 
    return

def mutation(): 
    return 

def genetic_algorithm(): 
     initialize_organisms()
     for i in range(0, n_iterations):
        selection()
        crossover()
        mutation()
     #print(fitness_generation)
     

if __name__ == "__main__":
        start_time = time.time()
        # # for i in np.arange(0, 1.9, 0.2):
        # #     coeff = evaluate_t_constraints([[1,0.3],[2, 1],[1, 1]])
        # #     #print(coeff)
        # #     print(solve_for_G_of_omega(coeff))
        genetic_algorithm()
        # coeff = evaluate_t_constraints(generation[0])
        # print(coeff)
        # print(solve_for_G_of_omega(coeff))
        end_time = time.time()
        print("Time Elapsed = ", end_time - start_time)
        #print(min_fitness_transformation_function(np.array([1, 1, 2])))